-- phpMyAdmin SQL Dump
-- version 3.3.9
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Nov 22, 2016 at 01:09 PM
-- Server version: 5.5.8
-- PHP Version: 5.3.5

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `login_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE IF NOT EXISTS `login` (
  `id` int(22) NOT NULL,
  `username` varchar(22) NOT NULL,
  `password` varchar(222) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`id`, `username`, `password`) VALUES
(1, 'admin', 'admin'),
(2, 'joker', 'joker');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(30) NOT NULL,
  `email` varchar(30) NOT NULL,
  `password` varchar(30) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `gender` int(10) NOT NULL,
  `address` varchar(100) NOT NULL,
  `date` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=82 ;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `email`, `password`, `phone`, `gender`, `address`, `date`) VALUES
(81, 'bikash.shahi65@gmail.com', 'bikash.shahi65@gmail.com', 'bikash.shahi65@gmail.com', 'bikash.shahi65@gmail', 0, 'bikash.shahi65@gmail.com', '2016-11-21 06:02:05'),
(73, 'shailesh', 'shailesh@gmail.com', '123456', '123456789', 0, '12345789', '0000-00-00 00:00:00'),
(72, 'Joker', 'joker@gmail.com', 'B_joke65', '9851171948', 0, 'Talchikhel', '2016-11-11 11:16:35'),
(75, 'bikash shahi', 'asdfasdf@123', 'asdfasdf@123', 'asdfasdf@123', 0, 'asdfasdf@123', '0000-00-00 00:00:00'),
(80, 'bikash@ekbana.com', 'bikash@ekbana.com', 'bikash@ekbana.com', 'bikash@ekbana.com', 0, 'bikash@ekbana.com', '2016-11-18 12:37:42'),
(77, 'cytoshna', 'cytoshna@gmail.com', '123456', '123456789', 1, '123456789', '0000-00-00 00:00:00'),
(79, 'Jokerni', 'jokermi@gmail.com', 'hello123', '9807728019', 1, 'laganhkhel', '2016-11-18 09:36:21');
