<!doctype html>
<html>
<head>
<meta charset="utf-8" />
	<link rel="apple-touch-icon" sizes="76x76" href="projects/assets/img/apple-icon.png">
	<link rel="icon" type="image/png" sizes="96x96" href="projects/assets/img/favicon.png">
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
    
<title>Mahalaxmi Cold Store</title>
    
    
    <link href="projects/assets/css/bootstrap.min.css" rel="stylesheet" type="text/css">


    <link href="projects/assets/css/animate.min.css" rel="stylesheet" type="text/css">
    <link href="css/custom.css" rel="stylesheet" type="text/css">
    <link href="css/query.css" rel="stylesheet" type="text/css">
    
    
    
    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
        <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
        <!--[if lt IE 9]>
          <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
          <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
        <![endif]-->
        <!-- Start WOWSlider.com HEAD section --> <!-- add to the <head> of your page -->
        <link rel="stylesheet" type="text/css" href="engine0/style.css" />

        <script type="text/javascript" src="engine0/jquery.js"></script>
        <!-- End WOWSlider.com HEAD section -->


</head>

<body>

<header>

         <div class="nav-section nav_main clearfix">
            <div class="container ">
                <nav class="navbar-wrapper navbar-default nav_def" role="navigation" >
                    <div class="navbar-header tog_btn">

                        <button type="button" class="navbar-toggle " data-toggle="collapse" data-target=".navbar-collapse">
                            <span class="sr-only">Toggle navigation</span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                        </button>

                        
                        <div class="logo">
                                <a href="#"><img src="icons/logo.png"></a>
                            </div>
                    </div>

                    <div class="navbar-collapse collapse nav_cos " >
                        <ul class="nav navbar-nav main-nav nav_ul">
                             <li><a href="#">ABOUT</a></li>
                             <li><a href="#">FEATURES</a></li>
                             <li><a href="#">FAQS</a><li>
                             <li class="btn_hov">
                            
                        		<button type="button" class="Login" data-toggle="modal" data-target="#myModal2">LOGIN</button>
                        		<button type="button" class="sign_up " data-toggle="modal" data-target="#myModal">SIGN UP</button>
                        	
                             </li>
         				</ul>
                        
                    </div>
                </nav>
            </div>
        </div><!-- nav-section -->


    	<div class="home-banner-section clearfix">
            <!-- Start WOWSlider.com BODY section -->
            <div id="wowslider-container0">
            <div class="ws_images"><ul>
                <li><img src="images/home-banner/1.jpg" alt="bootstrap carousel" title="" id="wows0_0"/></li>

                <!--<li><img src="images/home-banner/1.jpg" alt="bootstrap carousel" title="<b>ɪkɪˈbɑːnə </b> The Art of Flower Arrangement" id="wows0_0"/></li>-->

            </ul></div>
           
            <div class="ws_shadow"></div>
            </div>	
            <script type="text/javascript" src="engine0/wowslider.js"></script>
            <script type="text/javascript" src="engine0/script.js"></script>
            <!-- End WOWSlider.com BODY section -->
       
       
        </div><!-- end of home-banner-section -->
        
        
      
 
        
        
        
        <div class="head_det ">
            
            <div class="container ">
                <div class="row head_det2">
                
                         <div class="banner_details " align="center">
                         	<div class="head_lin">
                            <div class="ban_headline">
                                <h1>Nepal’s first online cold store</h1>
                                <h3>Mahalaxmi cold Store is Nepal’s first online order cold store</h3>
							</div>
                            </div>

                         </div>  <!--banner_details-->
                         
                         <div class="row prod_div ">
                                <div class="col-sm-2 col-sm-offset-1 product">
                                    <div class="all_prod product1">
                                        <a href="#"><img src="icons/meat1.png" class="img-responsive">
                                        <span>Chicken</span></a>
                                    </div>
                                </div>
                                
                                <div class="col-sm-2 product">
                                	<div class="all_prod product2">
                                        <a href="#"><img src="icons/meat2.png" class="img-responsive">
                                        <span>Mutten</span></a>
                                	</div>
                                </div>
                                
                                <div class="col-sm-2 product">
                                	<div class="all_prod product3">
                                        <a href="#"><img src="icons/meat3.png" class="img-responsive">
                                        <span>Ostrich</span></a>
                                	</div>
                                </div>
                                
                                <div class="col-sm-2 product">
                                	<div class=" all_prod product4">
                                        <a href="#"><img src="icons/meat4.png" class="img-responsive">
                                        <span>Sausage</span></a>
                                	</div>
                                </div>
                                
                                <div class="col-sm-2 product produt">
                                	<div class="all_prod product5">
                                        <a href="#"><img src="icons/meat5.png" class="img-responsive">
                                        <span>Other</span></a>
                                	</div>
                                </div>
                                
							</div>
                     
                     </div><!--row-->
                     </div> <!--container-->
                </div>

    </header>  
    
    <section  class="body_part">
   
   		 <!-- nav_menu -->
   
   		<div class="border_img"><img src="icons/border.jpg" class="img-responsive"></div>
        <div class="bg_imgs">
            
         </div>
        
        <div class="gb_img "> 
            <div class="container ">
                <div class="row ">
                    <div class="col-md-12 intro" align="center">
                    	
                        <h1>HOW TO ORDER</h1>
                        <h3>Mahalaxmi cold Store is Nepal’s first online order cold store</h3>
                        <spam>9:00 - 18:00</spam>
                     </div> <!-- end of intro -->
                    
                    
                    <div class="col-md-4 order_type" align="center">
                    	<img src="icons/order.png">
                        <h4>SELECT ORDER TYPE</h4>
                        <p>Mahalaxmi cold Store is Nepal’s first online order cold store Mahalaxmi cold Store is Nepal’s first online order cold store</p>
                     
                     </div> <!-- end of order_type -->
                     
                     <div class="col-md-4 order_type" align="center">
                    	<img src="icons/place_order.png">
                        <h4>FILL SIMPLE FORM</h4>
                        <p>Mahalaxmi cold Store is Nepal’s first online order cold store Mahalaxmi cold Store is Nepal’s first online order cold store</p>
                     
                     </div> <!-- end of order_type -->
                     
                     <div class="col-md-4 order_type" align="center">
                    	<img src="icons/deliver_ic.png">
                        <h4>ORDER ONLINE, ENJOY</h4>
                        <p>Mahalaxmi cold Store is Nepal’s first online order cold store Mahalaxmi cold Store is Nepal’s first online order cold store</p>
                     
                     </div> <!-- end of order_type -->
                     
                     
                     <div class="col-md-12 intro" align="center">
                    	
                        <h1>OUR QUAILTY MEAT PRODUCTS</h1>
                        <h3>Mahalaxmi cold Store is Nepal’s first online order cold store</h3>
                     </div> <!-- end of intro -->
                  
                    
                </div>  <!-- end of row -->
            </div>  <!-- end of container -->
          </div> <!-- end of gb_img -->
        
       
       
     <h1>hello this is </h1>
     <h1>hello this is </h1>
     <h1>hello this is </h1>
     <h1>hello this is </h1>
     <h1>hello this is </h1>
     <h1>hello this is </h1>
     <h1>hello this is </h1>
     <h1>hello this is </h1>
     <h1>hello this is </h1>
     <h1>hello this is </h1>
       
          
          
         
          
          
          
   
   </section>



<!--Sign in model-->

<!-- Modal -->
      
      <div class="modal fade log_model_bg" id="myModal2" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
  <div class="modal-dialog" role="document">
    <div class="modal-content ">
      <div class="modal-header">
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                                <h4 class="modal-title" id="myModalLabel">Log In</h4>
                              </div>
                              <div class="modal-body">
                                <form data-toggle="validator" role="form" method="POST" action="projects/register.php">
                          <div class="form-group">
                            <label for="inputName" class="control-label">Username</label>
                            <input type="text" class="form-control " id="inputName" placeholder="Full Name"  name="username" required>
                          </div>
                          
                           <div class="form-group">
                            <label for="inputPassword" class="control-label">Password</label>
                            <input type="password" data-minlength="6" class="form-control " id="inputPassword" placeholder="Password"  name="password" required>
                          </div>
                          <div class="error_msg">Username or password not match</div>                   
                          
                          
                          
                   			</div>
      <div class="modal-footer">
        <div class="form-group">
        <div class="forget"> <a href="#">Forgot your password ?</a></div>
     <input type="submit" name="submit" value="Log In" class="Log_in" />
  </div>
      </div>
                        </form>
      
    </div>
  </div>
</div>




<!--Sign up model-->

<!-- Modal -->
      
      <div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                                <h4 class="modal-title" id="myModalLabel">Sign Up</h4>
                              </div>
                              <div class="modal-body">
                                <form data-toggle="validator" role="form" method="POST" action="projects/register.php">
                          <div class="form-group">
                            <label for="inputName" class="control-label">Name</label>
                            <input type="text" class="form-control " id="inputName" placeholder="Full Name"  name="username" required>
                          </div>
                          
                          <div class="form-group">
                            <label for="inputEmail" class="control-label">Email</label>
                            <input type="email" class="form-control" id="inputEmail" placeholder="Email" data-error="Bruh, that email address is invalid"  name="email" required>
                            <div class="help-block with-errors"></div>
                          </div>
                                              
                          <div class="form-group">
                            <label for="inputName" class="control-label">Phone</label>
                            <input type="text" class="form-control " id="inputName" placeholder="Mobile"  name="phone" required>
                          </div>
                          
                          <div class="form-group">
                            <label for="inputName" class="control-label">Address</label>
                            <input type="text" class="form-control " id="inputName" placeholder="Location, Street"  name="address" required>
                          </div>
                          
                          
                          <div class="form-group">
                            <label for="inputPassword" class="control-label ">Password</label>
                            <div class="form-inline row">
                              <div class="form-group col-sm-6">
                                <input type="password" data-minlength="6" class="form-control " id="inputPassword" placeholder="Password"  name="password" required>
                                <div class="help-block">Minimum of 6 characters</div>
                              </div>
                              <div class="form-group col-sm-6">
                                <input type="password" class="form-control" id="inputPasswordConfirm" data-match="#inputPassword" data-match-error="Whoops, these don't match" placeholder="Confirm" required>
                                <div class="help-block with-errors"></div>
                              </div>
                            </div>
                          </div>
                          <div class="form-group">
                            <div class="radio">
                              <label>
                                <input type="radio" name="gender" value="0" required>
                                Male
                              </label>
                            </div>
                            <div class="radio">
                              <label>
                                <input type="radio" name="gender" value="1" required>
                                Female
                              </label>
                            </div>
                          </div>
                          
                   			</div>
      <div class="modal-footer">
        <div class="form-group">
     <input type="submit" name="submit" value="Sign Up" class="Log_in" />
  </div>
      </div>
                        </form>
      
    </div>
  </div>
</div>


</body>




    <!--   Core JS Files   -->
    <script src="projects/assets/js/jquery-1.10.2.js" type="text/javascript"></script>
	<script src="projects/assets/js/bootstrap.min.js" type="text/javascript"></script>

	<!--  Checkbox, Radio & Switch Plugins -->
	<script src="projects/assets/js/bootstrap-checkbox-radio.js"></script>

	<!--  Charts Plugin -->
	<script src="projects/assets/js/chartist.min.js"></script>

    <!--  Notifications Plugin    -->
    <script src="projects/assets/js/bootstrap-notify.js"></script>

    <!--  Google Maps Plugin    -->
    <script src="projects/assets/js/googleapis_map.js">
    </script>

    <!-- Paper Dashboard Core javascript and methods for Demo purpose -->
	<script src="projects/assets/js/paper-dashboard.js"></script>

	<!-- Paper Dashboard DEMO methods, don't include it in your project! -->
	<script src="projects/assets/js/demo.js"></script>


    
<script src="projects/assets/js/validation.js"></script>

<!--Delete Alert-->
    
    <script src="projects/assets/js/sweetalert.js" ></script>


<script type="text/javascript">


    $('.remove').click(function(){

      swal({

          title: "Are you sure want to remove this item?",

          text: "You will not be able to recover this item",

          type: "warning",

          showCancelButton: true,

          confirmButtonClass: "btn-danger",

          confirmButtonText: "Confirm",

          cancelButtonText: "Cancel",

          closeOnConfirm: false,

          closeOnCancel: false

        },

        function(isConfirm) {

          if (isConfirm) {

            swal("Deleted!", "Your item deleted.", "success");

          } else {

            swal("Cancelled", "You Cancelled", "error");

          }

      });

    });
	
	

$(document).ready(function(){
    /* affix the navbar after scroll below header */
    $(".nav_main").affix({offset: {top: $(".home-banner-section").outerHeight(true)} });
});



</script>

</html>
