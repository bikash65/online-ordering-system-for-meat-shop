
<?php include 'header.php';?>
<?php include 'sidebar.php';?>
<?php include 'top_menu.php';?>




	


		<div class="content">
			<div class="container-fluid">
				<div class="row">
					<div class="col-lg-3 col-sm-6 ">
						<div class="card Dash_show1">
							<div class="content">
								<div class="row ">
									<div class="col-xs-4">
										<div class="icon-big icon-warning text-center">
											<i class="fa fa-truck" aria-hidden="true"></i>

										</div>
									</div>
									<div class="col-xs-7">
										<div class="numbers">
											<p>ORDER</p>
											03 
										</div>
									</div>
								</div>
								
							</div>
						</div>
					</div>
					
					<div class="col-lg-3 col-sm-6 ">
						<div class="card Dash_show2">
							<div class="content">
								<div class="row ">
									<div class="col-xs-4">
										<div class="icon-big icon-warning text-center">
											<i class="fa fa-user" aria-hidden="true"></i>


										</div>
									</div>
									<div class="col-xs-7">
										<div class="numbers">
											<p>TOTAL USERS</p>
											240
										</div>
									</div>
								</div>
								
							</div>
						</div>
					</div>
					
					<div class="col-lg-3 col-sm-6 ">
						<div class="card Dash_show3">
							<div class="content">
								<div class="row ">
									<div class="col-xs-4">
										<div class="icon-big icon-warning text-center">
											<i class="fa fa-pie-chart" aria-hidden="true"></i>

										</div>
									</div>
									<div class="col-xs-7">
										<div class="numbers">
											<p>ORDER</p>
											N/A
										</div>
									</div>
								</div>
								
							</div>
						</div>
					</div>
					
					<div class="col-lg-3 col-sm-6 ">
						<div class="card Dash_show4">
							<div class="content">
								<div class="row ">
									<div class="col-xs-4">
										<div class="icon-big icon-warning text-center">
											<i class="fa fa-pie-chart" aria-hidden="true"></i>

										</div>
									</div>
									<div class="col-xs-7">
										<div class="numbers">
											<p>ORDER</p>
											N/A
										</div>
									</div>
								</div>
								
							</div>
						</div>
					</div>
					
					
					
				</div>
				
				
				
				<!-- New order list and past order list -->
				
   
   
   
   
				<div class="row">
					<div class="col-md-7">
					
					<h4 class="title">New Order</h4>
                     
						<div class="card">
							<div class="content table-responsive table-full-width">
								<table class="table table-striped">
									<thead class="table_header">
									   <th></th>
										<th>Name</th>
										<th>Product</th>
										<th>Delivery</th>
										<th>Action</th>
									</thead>
									<tbody>
										<tr>
											<td></td>
											<td>Dakota Rice</td>
											<td>Mutton</td>
											
											
											<td>26 Jun, 2016</td>
											<td>
												<a href="#" class="actived" style="display:none;">Active</a> 
												
												<a href="#" class="Pending" style="display:inline-block;">Pending</a>


												<button type="button" class="edit2" data-toggle="modal" data-target="#myModal">
													<a href="#"style="display:inline-block;"><i class="fa fa-pencil edit" aria-hidden="true"></i></a>
												</button> 
												<button class="remove"><i class="fa fa-trash delete" aria-hidden="true"></i></button>
											</td>
										</tr>
										
										<tr>
											<td></td>
											<td>Dakota Rice</td>
											<td>Mutton</td>
											
											
											<td>26 Jun, 2016</td>
											<td>
												<a href="#" class="actived" style="display:none;">Active</a> 
												<a href="#" class="Pending" style="display:inline-block;">Pending</a> 
												<button type="button" class="edit2" data-toggle="modal" data-target="#myModal">
													<a href="#"style="display:inline-block;"><i class="fa fa-pencil edit" aria-hidden="true"></i></a>
												</button>
												<button class="remove"><i class="fa fa-trash delete" aria-hidden="true"></i></button>
											</td>
										</tr>
										<tr>
											<td></td>
											<td>Dakota Rice</td>
											<td>Mutton</td>
											
											
											<td>26 Jun, 2016</td>
											<td>
												<a href="#" class="actived" style="display:none;">Active</a> 
												<a href="#" class="Pending" style="display:inline-block;">Pending</a> 
												<button type="button" class="edit2" data-toggle="modal" data-target="#myModal">
													<a href="#"style="display:inline-block;"><i class="fa fa-pencil edit" aria-hidden="true"></i></a>
												</button>
												<button class="remove"><i class="fa fa-trash delete" aria-hidden="true"></i></button>
											</td>
										</tr>
										
									</tbody>
								</table>

							</div>
						</div>
					</div>
					
					
					<div class="col-md-5">
					
					<h4 class="title">New testimonials</h4>
						<div class="card">
							<div class="content table-responsive table-full-width">
								<table class="table table-striped">
									<thead class="table_header">
									   <th></th>
										<th>Name</th>
										<th>Message</th>
										
										<th>Create</th>
										
										<th>Action</th>
									</thead>
									<tbody>
										<tr>
											<td></td>
											<td>Dakota Rice</td>
											<td>It is easy to use and does what...</td>
											
											
											<td>26 Jun, 2016</td>
											<td>
												<a href="#" class="actived" style="display:none;">Active</a> 
												<a href="#" class="Pending" style="display:inline-block;">Pending</a> 
												<button type="button" class="edit2" data-toggle="modal" data-target="#myModal">
													<a href="#"style="display:inline-block;"><i class="fa fa-pencil edit" aria-hidden="true"></i></a>
												</button>
												<button class="remove"><i class="fa fa-trash delete" aria-hidden="true"></i></button>
											</td>
										</tr>
										
										<tr>
											<td></td>
											<td>Dakota Rice</td>
											<td>what you need it to when you need to do it. With Cision, </td>
											
											
											<td>26 Jun, 2016</td>
											<td>
												<a href="#" class="actived" style="display:none;">Active</a> 
												<a href="#" class="Pending" style="display:inline-block;">Pending</a> 
												<button type="button" class="edit2" data-toggle="modal" data-target="#myModal">
													<a href="#"style="display:inline-block;"><i class="fa fa-pencil edit" aria-hidden="true"></i></a>
												</button>
												<button class="remove"><i class="fa fa-trash delete" aria-hidden="true"></i></button>
											</td>
										</tr>
										
										
										
										
										
									</tbody>
								</table>

							</div>
						</div>
					</div>
					

					<div class="col-md-12">
						<div class="card card-plain">
							</br> </br>
								<h4 class="title">Past Order</h4>

						 
							<div class="content table-responsive table-full-width">
								<table class="table table-hover">
									<thead class="table_header">
										
										<th>Name</th>
										<th>Adress</th>
										<th>Phone</th>
										<th>Create</th>
										<th>Delivery</th>
										<th>Status</th>
									</thead>
									<tbody>
										 <tr>
											
											<td>Dakota Rice</td>
											<td>Pulchowk</td>
											<td>+977-9843-00-1234</td>
											<td>24 Jun, 2016</td>
											<td>26 Jun, 2016</td>
											<td>
												<a href="#" class="actived">Success</a> 
						 
											</td>
										</tr>
										
										<tr>
											
											<td>Angelina Joli</td>
											<td>Pulchowk</td>
											<td>+977-9843-00-1234</td>
											<td>22 Jun, 2016</td>
											<td>26 Jun, 2016</td>
											<td>
												<a href="#" class="actived" style="display:none;">Active</a> 
												<a href="#" class="cancel_order" style="display:inline-block;">Canceled</a>
	 
											</td>
										</tr>
										
										<tr>
											
											<td>Dakota Rice</td>
											<td>Pulchowk</td>
											<td>+977-9843-00-1234</td>
											<td>22 Jun, 2016</td>
											<td>28 Jun, 2016</td>
											<td>
												<a href="#" class="actived">Success</a> 

											</td>
										</tr>
										
										 <tr>
											
											<td>Dakota Rice</td>
											<td>Pulchowk</td>
											<td>+977-9843-00-1234</td>
											<td>24 Jun, 2016</td>
											<td>26 Jun, 2016</td>
											<td>
												<a href="#" class="actived">Success</a> 

											</td>
										</tr>
										
										<tr>
											
											<td>Angelina Joli</td>
											<td>Pulchowk</td>
											<td>+977-9843-00-1234</td>
											<td>22 Jun, 2016</td>
											<td>26 Jun, 2016</td>
											<td>
												<a href="#" class="actived" style="display:none;">Active</a> 
												<a href="#" class="cancel_order" style="display:inline-block;">Canceled</a>

											</td>
										</tr>
										
										<tr>
											
											<td>Dakota Rice</td>
											<td>Pulchowk</td>
											<td>+977-9843-00-1234</td>
											<td>22 Jun, 2016</td>
											<td>28 Jun, 2016</td>
											<td>
												<a href="#" class="actived">Success</a> 

											</td>
										</tr>

										
									</tbody>
								</table>

							</div>
						</div>
					</div>


				</div>

				
				
				
				
				
				<!--<div class="row">
					<div class="col-md-6">
						<div class="card">
							<div class="header">
								<h4 class="title">Email Statistics</h4>
								<p class="category">Last Campaign Performance</p>
							</div>
							<div class="content">
								<div id="chartPreferences" class="ct-chart ct-perfect-fourth"></div>

								<div class="footer">
									<div class="chart-legend">
										<i class="fa fa-circle text-info"></i> Open
										<i class="fa fa-circle text-danger"></i> Bounce
										<i class="fa fa-circle text-warning"></i> Unsubscribe
									</div>
									<hr>
									<div class="stats">
										<i class="ti-timer"></i> Campaign sent 2 days ago
									</div>
								</div>
							</div>
						</div>
					</div>
					<div class="col-md-6">
						<div class="card ">
							<div class="header">
								<h4 class="title">2015 Sales</h4>
								<p class="category">All products including Taxes</p>
							</div>
							<div class="content">
								<div id="chartActivity" class="ct-chart"></div>

								<div class="footer">
									<div class="chart-legend">
										<i class="fa fa-circle text-info"></i> Tesla Model S
										<i class="fa fa-circle text-warning"></i> BMW 5 Series
									</div>
									<hr>
									<div class="stats">
										<i class="ti-check"></i> Data information certified
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>--> <!-- pie chart -->
			</div>
		</div>


		<footer class="footer">
			<div class="container-fluid">
			 
				<div class="copyright pull-right">
					&copy; <script>document.write(new Date().getFullYear())</script>, made with <i class="fa fa-heart heart"></i> by <a href="http://www.mahalaxmicoldstore.com.np">Bikaash</a>
				</div>
			</div>
		</footer>

	</div>
</div>



<!--Model-->

<!-- Modal -->
<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
  <div class="modal-dialog" role="document">
	<div class="modal-content">
	  <div class="modal-header">
		<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
		<h4 class="modal-title" id="myModalLabel">Modal title</h4>
	  </div>
	  <div class="modal-body">
		...
	  </div>
	  <div class="modal-footer">
		<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
		<button type="button" class="btn btn-primary">Save changes</button>
	  </div>
	</div>
  </div>
</div>


<?php include 'footer.php'; ?>


