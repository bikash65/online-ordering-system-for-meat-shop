<?php 
include 'header.php';
include 'sidebar.php';
include 'top_menu.php';
?>

   


        <div class="content">
            <div class="container-fluid">
                
                
                
                
                <!-- New order list and past order list -->
                
   
   
   
   
                <div class="row">
                    <div class="col-md-12">
                    
                    <h4 class="title">New testimonials</h4>
                        <div class="card">
                            <div class="content table-responsive table-full-width">
                                <table class="table table-striped">
                                    <thead class="table_header">
                                       <th></th>
                                    	<th>Name</th>
                                        <th>Message</th>
                                        
                                    	<th>Create</th>
                                    	
                                    	<th>Action</th>
                                    </thead>
                                    <tbody>
                                        <tr>
                                        	<td></td>
                                        	<td>Dakota Rice</td>
                                            <td>It is easy to use and does what...</td>
                                        	
                                        	
                                        	<td>26 Jun, 2016</td>
                                            <td>
                                            	<a href="#" class="actived" style="display:none;">Active</a> 
                                                <a href="#" class="Pending" style="display:inline-block;">Pending</a> 
                                                <button type="button" class="edit2" data-toggle="modal" data-target="#myModal">
                                                	<a href="#"style="display:inline-block;"><i class="fa fa-pencil edit" aria-hidden="true"></i></a>
                                                </button>
                                                <button class="remove"><i class="fa fa-trash delete" aria-hidden="true"></i></button>
											</td>
                                        </tr>
                                        
                                        <tr>
                                        	<td></td>
                                        	<td>Dakota Rice</td>
                                            <td>what you need it to when you need to do it. With Cision, </td>
                                        	
                                        	
                                        	<td>26 Jun, 2016</td>
                                            <td>
                                            	
                                                <a href="#" class="Pending" style="display:inline-block;">Pending</a> 
                                                <button type="button" class="edit2" data-toggle="modal" data-target="#myModal">
                                                	<a href="#"style="display:inline-block;"><i class="fa fa-pencil edit" aria-hidden="true"></i></a>
                                                </button>
                                                <button class="remove"><i class="fa fa-trash delete" aria-hidden="true"></i></button>
											</td>
                                        </tr>
                                        
                                        <tr>
                                        	<td></td>
                                        	<td>Dakota Rice</td>
                                            <td>It is easy to use and does what...</td>
                                        	
                                        	
                                        	<td>26 Jun, 2016</td>
                                            <td>
                                        
                                                <a href="#" class="actived" style="display:inline-block;">Active</a> 
                                                <button type="button" class="edit2" data-toggle="modal" data-target="#myModal">
                                                	<a href="#"style="display:inline-block;"><i class="fa fa-pencil edit" aria-hidden="true"></i></a>
                                                </button>
                                                <button class="remove"><i class="fa fa-trash delete" aria-hidden="true"></i></button>
											</td>
                                        </tr>
                                        
                                        <tr>
                                        	<td></td>
                                        	<td>Dakota Rice</td>
                                            <td>what you need it to when you need to do it. With Cision, </td>
                                        	
                                        	
                                        	<td>26 Jun, 2016</td>
                                            <td>
                                            	
                                                <a href="#" class="actived" style="display:inline-block;">Active</a> 
                                                <button type="button" class="edit2" data-toggle="modal" data-target="#myModal">
                                                	<a href="#"style="display:inline-block;"><i class="fa fa-pencil edit" aria-hidden="true"></i></a>
                                                </button>
                                                <button class="remove"><i class="fa fa-trash delete" aria-hidden="true"></i></button>
											</td>
                                        </tr>
                                        
                                        
                                        
                                        
                                        
                                    </tbody>
                                </table>

                            </div>
                        </div>
                    </div>

                    

                </div>

                
                
                
                
                
                <!--<div class="row">
                    <div class="col-md-6">
                        <div class="card">
                            <div class="header">
                                <h4 class="title">Email Statistics</h4>
                                <p class="category">Last Campaign Performance</p>
                            </div>
                            <div class="content">
                                <div id="chartPreferences" class="ct-chart ct-perfect-fourth"></div>

                                <div class="footer">
                                    <div class="chart-legend">
                                        <i class="fa fa-circle text-info"></i> Open
                                        <i class="fa fa-circle text-danger"></i> Bounce
                                        <i class="fa fa-circle text-warning"></i> Unsubscribe
                                    </div>
                                    <hr>
                                    <div class="stats">
                                        <i class="ti-timer"></i> Campaign sent 2 days ago
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="card ">
                            <div class="header">
                                <h4 class="title">2015 Sales</h4>
                                <p class="category">All products including Taxes</p>
                            </div>
                            <div class="content">
                                <div id="chartActivity" class="ct-chart"></div>

                                <div class="footer">
                                    <div class="chart-legend">
                                        <i class="fa fa-circle text-info"></i> Tesla Model S
                                        <i class="fa fa-circle text-warning"></i> BMW 5 Series
                                    </div>
                                    <hr>
                                    <div class="stats">
                                        <i class="ti-check"></i> Data information certified
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>--> <!-- pie chart -->
            </div>
        </div>


        <footer class="footer">
            <div class="container-fluid">
             
                <div class="copyright pull-right">
                    &copy; <script>document.write(new Date().getFullYear())</script>, made with <i class="fa fa-heart heart"></i> by <a href="http://www.mahalaxmicoldstore.com.np">Bikaash</a>
                </div>
            </div>
        </footer>

    </div>
</div>



<!--Sign up model-->

<!-- Modal -->




<?php include 'footer.php'; ?>
