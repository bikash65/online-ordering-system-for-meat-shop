
    <?php  
	
	 require_once('config.php');  
        class DbConnect {    
		
            function __construct() {  
               
                $conn = mysql_connect('localhost', 'root', '');  
                mysql_select_db('login_db', $conn);  
                if(!$conn)// testing the connection  
                {  
                    die ("Cannot connect to the database");  
                }   
                return $conn;  
            }  
            public function Close(){  
                mysql_close();  
            }  
			
			
        }  
    ?>  