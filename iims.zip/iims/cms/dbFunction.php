
    <?php  
    require_once 'dbConnect.php';  
    session_start();  
        class dbFunction {  
           
            function __construct() {  
			
                  
                // connecting to database  
                $db = new dbConnect();
                   
            }  
            // destructor  
            function __destruct() {  
                  
            }  
          
            public function Login($username, $password){  
                $query = "SELECT * FROM login WHERE username = '".$username."' AND password = '".$password."'";
				$res = mysql_query($query); 
				 
                $user_data = mysql_fetch_array($res);  
                //print_r($user_data);  
                $no_rows = mysql_num_rows($res);  
                if ($no_rows >= 1)   
                {  
                    $_SESSION['login'] = true;  
                    $_SESSION['uid'] = $user_data['id'];  
                    $_SESSION['username'] = $user_data['username'];    
                    return true;  
                }  
                else  
                {  
                 return false;
                }  
                   
                       
            }  
            public function isUserExist($username){  
                $qr = mysql_query("SELECT * FROM users WHERE username = '".$username."'");  
                echo $row = mysql_num_rows($qr);  
                if($row > 0){  
                    return true;  
                } else {  
                    return false;  
                }  
            }  
         
		
			public function insertUser($insertData){
			
			$username = $insertData['username'];
			$email = $insertData['email'];
			$password = $insertData['password'];	

			$address = $insertData['address'];
			$phone = $insertData['phone'];
			$gender = $insertData['gender'];
			$date = date("y-m-d H:i:s");

			$query ="INSERT INTO users (username,password,email,address,phone,gender,date) VALUES ('$username', '$password', '$email', '$address', '$phone',$gender,'$date')";
			
			


			
			$res = mysql_query($query);

			if ($res) {
			return true;
			}
			return false;
			
			}
			
			public function getUserData(){  
                $qr = mysql_query("SELECT * FROM users order by date DESC");  
                 $row = mysql_num_rows($qr); 
				 $arr = array();
				 $counter =0;
				 while($res = mysql_fetch_assoc($qr)){
					 $arr[$counter] = 
					 array(
					  "id"=> $res["id"],
					 "username"=> $res["username"],
					  "email"=> $res["email"],
					    "address"=> $res["address"],
						"phone"=> $res["phone"],
						"password"=> $res["password"],
						"gender"=> $res["gender"],
						"date"=> $res["date"],
					 ); 
				$counter ++;
					 }
				return $arr;  
            }  
			
			
			}
			

?>
		
		
		
		
		
		
		
		 
   