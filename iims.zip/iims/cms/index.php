<?php
  include('header.php');
?>
  <body>

    <!--Google Font - Work Sans-->
<link href='https://fonts.googleapis.com/css?family=Work+Sans:400,300,700' rel='stylesheet' type='text/css'>


<div class="container">
  <div class="profile">
    <button class="profile__avatar" id="toggleProfile">
     <img src="img/logo.png" alt="Avatar" /> 
    </button>
    <div class="profile__form">
      <div class="profile__fields">
        <div class="field">
        	<form name="login" method="post" action="admin.php">
          <input type="text" id="fieldUser" class="input"  name="username"required pattern=.*\S.* />
          <label for="fieldUser" class="label">Username</label>
        </div>
        <div class="field">
          <input type="password" id="fieldPassword" name="password" class="input" required pattern=.*\S.* />
          <label for="fieldPassword" class="label">Password</label>
        </div>
        <div class="profile__footer">
          <input type="submit" name="submit" value="login" class="btn" />
          </form>
          
          

      </div>
     </div>
  </div>
  <div style = "font-size:13px; color:#fff; margin-top:10px" align="center"><?php echo isset($_GET['error']) ? $_GET['error'] : ""; ?>
        </div>
</div>
    
        <script src="js/index.js"></script>

    
    
    
  </body>
</html>
