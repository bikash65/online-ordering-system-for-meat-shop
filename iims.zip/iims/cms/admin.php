<?php 
 include_once('dbFunction.php'); 
     $funObj = new dbFunction(); 
if(isset($_POST['submit'])){
	$username=$_POST['username'];
	$password=$_POST['password'];
	$user = $funObj->Login($username, $password); 
	


        if ($user) { 
		 // Registration Success  
         //  header("location:../projects");
        	header("location:../projects/dashboard.php");

			   
           
        } else {  
		 // Registration Failed
        	 $error = "Invalid Login Please Try Again"; 
		 header("location:../cms/index.php?error=".$error);         
           
        }   
	}else{
		echo 'false';
		}


?>
